# c4c.p4contextinfo

Orion-LD e Mongo-DB inicializados em conteiners através do Docker.