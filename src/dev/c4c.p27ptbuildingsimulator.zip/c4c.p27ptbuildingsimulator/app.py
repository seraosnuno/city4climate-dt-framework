from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel
import pandas as pd
import os
import uvicorn
import numpy as np
from sqlalchemy import create_engine, text

app = FastAPI(title="Digital Twin C4C - Guimarães Prediction Engine (P25)")

# --- CONFIGURAÇÕES DE CAMINHOS ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Ajustado para o ficheiro que deve estar na raiz ou pasta de dados do P25
PATH_TODOS = os.path.join(BASE_DIR, "e8_todos_kw.csv") 
FOLDER_IA = os.path.join(BASE_DIR, "modelo_nn")

# --- NOVO: Carregamento do Rácio Específico de Guimarães ---
PATH_RACIO = os.path.join(FOLDER_IA, "racio_freguesias_guimaraes.csv")

# --- CONFIGURAÇÕES DA BASE DE DADOS (TimescaleDB via Docker) ---
DB_USER = os.getenv("DB_USER", "quantumleap")
DB_PASS = os.getenv("DB_PASS", "12345")
DB_NAME = os.getenv("DB_NAME", "quantumleap")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5433") # Porta mapeada no docker-compose do colega
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# Criamos o engine da base de dados
engine = create_engine(DATABASE_URL)

# Globais para a IA
nn_model = None
scaler = None
encoder = None

# Modelos Pydantic
class SimulacaoInput(BaseModel):
    concelho: str
    freguesia: str
    trimestre: str # Agora recebe "2026T1"
    num_instalacoes: int

class MetaInput(BaseModel):
    concelho: str
    freguesia: str
    trimestre: str # Agora recebe "2026T1"
    potencia_alvo_kw: float

# --- ROTA 1: HISTÓRICO (Legado CSV) ---
@app.get("/historico")
def obter_historico(
    concelho: str = Query(None, description="guimaraes, porto ou lisboa. Se omitido, envia tudo.")
):
    try:
        if not os.path.exists(PATH_TODOS):
            raise FileNotFoundError(f"Ficheiro {PATH_TODOS} não encontrado.")

        df = pd.read_csv(PATH_TODOS).fillna(0)

        if concelho:
            target = concelho.lower().replace("ã", "a").replace("õ", "o").strip()
            mask = df["Concelho"].str.lower().str.replace("ã", "a").str.replace("õ", "o") == target
            df_filtered = df[mask]
        else:
            df_filtered = df

        if df_filtered.empty and concelho:
            raise HTTPException(status_code=404, detail=f"Concelho '{concelho}' não encontrado.")

        return {
            "status": "success",
            "concelho_visualizado": concelho if concelho else "Todos",
            "total_registos": len(df_filtered),
            "data": df_filtered.to_dict(orient="records"),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# --- NOVA ROTA: HISTÓRICO (Base de Dados Timescale) ---
@app.get("/historico-db")
def obter_historico_db(concelho: str = Query(None)):
    try:
        query_str = "SELECT * FROM historico_potencia"
        if concelho:
            term = concelho.strip()
            if term.lower().endswith('es'):
                term = term[:-2]
            
            query_str += f" WHERE concelho ILIKE '{term}%'"
        
        with engine.connect() as conn:
            df_db = pd.read_sql(text(query_str), conn)

        if not df_db.empty:
            df_db['trimestre'] = df_db['ano'].astype(str) + df_db['trimestre_num'].astype(str)
            df_db = df_db.rename(columns={
                "num_instalacoes": "numero_instalacoes",
                "potencia_total_instalada_upac_kw": "potencia_total_instalada_kw"
            })
            df_db = df_db[["trimestre", "concelho", "freguesia", "numero_instalacoes", "potencia_total_instalada_kw"]]

        return {
            "status": "success",
            "origem": "TimescaleDB (Container)",
            "total_registos": len(df_db),
            "data": df_db.to_dict(orient="records")
        }
    except Exception as e:
        print(f"Erro ao consultar DB: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro na DB: {str(e)}")
        
# --- ROTA 2: SIMULAÇÃO (IA V2.1) ---
@app.post("/simular")
def simular_potencia(data: SimulacaoInput):
    global nn_model, scaler, encoder
    try:
        # Extrair Ano e Trimestre da string "2026T1"
        try:
            ano_val = int(data.trimestre[:4])
            tri_val = int(data.trimestre[-1])
        except:
            raise HTTPException(status_code=400, detail="Formato de trimestre inválido. Use '2026T1'")

        if nn_model is None:
            import tensorflow as tf
            import joblib
            nn_model = tf.keras.models.load_model(os.path.join(FOLDER_IA, "nn_model.h5"), compile=False)
            scaler = joblib.load(os.path.join(FOLDER_IA, "nn_scaler.joblib"))
            encoder = joblib.load(os.path.join(FOLDER_IA, "nn_encoder.joblib"))

        # Carregar rácio específico de Guimarães para validar/usar na lógica se necessário
        # Nota: O simulador NN usa os pesos, mas podes usar o df_racio para lógica extra
        if os.path.exists(PATH_RACIO):
            df_racio = pd.read_csv(PATH_RACIO)

        cat_data = pd.DataFrame([[data.concelho, data.freguesia]], columns=["Concelho", "Freguesia"])
        encoded_cat = encoder.transform(cat_data)
        num_data = np.array([[ano_val, tri_val, data.num_instalacoes]])
        X_input = np.hstack([num_data, encoded_cat])
        X_scaled = scaler.transform(X_input)

        pred_racio = float(nn_model.predict(X_scaled, verbose=0)[0][0])
        racio_final = max(0.1, pred_racio)
        potencia_total = racio_final * data.num_instalacoes

        return {
            "status": "success",
            "metodologia": "Rede Neuronal V2.1 (Predição de Rácio)",
            "resultado": {
                "trimestre": data.trimestre,
                "concelho": data.concelho,
                "freguesia": data.freguesia,
                "numero_instalacoes": data.num_instalacoes,
                "potencia_total_instalada_kw": round(potencia_total, 2)
            },
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# --- ROTA 3: SIMULAR META (Inversa) ---
@app.post("/simular-meta-kw")
def simular_meta_kw(data: MetaInput):
    global nn_model, scaler, encoder
    try:
        # Extrair Ano e Trimestre da string "2026T1"
        try:
            ano_val = int(data.trimestre[:4])
            tri_val = int(data.trimestre[-1])
        except:
            raise HTTPException(status_code=400, detail="Formato de trimestre inválido. Use '2026T1'")

        if nn_model is None:
            import tensorflow as tf
            import joblib
            nn_model = tf.keras.models.load_model(os.path.join(FOLDER_IA, "nn_model.h5"), compile=False)
            scaler = joblib.load(os.path.join(FOLDER_IA, "nn_scaler.joblib"))
            encoder = joblib.load(os.path.join(FOLDER_IA, "nn_encoder.joblib"))

        cat_data = pd.DataFrame([[data.concelho, data.freguesia]], columns=["Concelho", "Freguesia"])
        encoded_cat = encoder.transform(cat_data)
        num_data_base = np.array([[ano_val, tri_val, 1]])
        X_input = np.hstack([num_data_base, encoded_cat])
        X_scaled = scaler.transform(X_input)

        pred_racio = float(nn_model.predict(X_scaled, verbose=0)[0][0])
        racio_final = max(0.1, pred_racio)
        num_necessario = data.potencia_alvo_kw / racio_final
        instalacoes_finais = int(np.ceil(num_necessario))

        return {
            "status": "success",
            "resultado": {
                "trimestre": data.trimestre,
                "concelho": data.concelho,
                "freguesia": data.freguesia,
                "numero_instalacoes_necessarias": instalacoes_finais,
                "potencia_alvo_kw": data.potencia_alvo_kw
            },
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# --- ROTA 4: PREVISÕES (Atualizado para TimescaleDB) ---
@app.get("/prever")
def obter_previsao(
    concelho: str = Query(None),
    freguesia: str = Query(None),
    ano: int = Query(None),
    trimestre: str = Query(None),
):
    try:
        query_str = "SELECT * FROM previsoes_potencia_todos_kw WHERE 1=1"
        
        if concelho:
            term = concelho.strip()
            if term.lower().endswith('es'):
                term = term[:-2]
            query_str += f" AND concelho ILIKE '{term}%'"

        if freguesia:
            query_str += f" AND freguesia ILIKE '{freguesia.strip()}%'"

        if ano:
            query_str += f" AND ano = {ano}"

        if trimestre:
            t_val = trimestre.upper() if "T" in trimestre.upper() else f"T{trimestre}"
            query_str += f" AND trimestre = '{t_val}'"

        with engine.connect() as conn:
            df = pd.read_sql(text(query_str), conn)

        if not df.empty:
            df['trimestre_full'] = df['ano'].astype(str) + df['trimestre'].astype(str)
            df = df.rename(columns={
                "trimestre_full": "trimestre",
                "num_instalacoes_previstas": "numero_instalacoes",
                "potencia_total_prevista_kw": "potencia_total_instalada_kw"
            })
            df = df[["trimestre", "concelho", "freguesia", "numero_instalacoes", "potencia_total_instalada_kw"]]

        return {
            "status": "success",
            "origem": "TimescaleDB (Previsões)",
            "total_previsoes": len(df),
            "data": df.to_dict(orient="records"),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8088)