# c4c.p25gmbuildingsimulator:

# C4C - P25 Guimarães Building Simulator API

Microserviço de predição e simulação de potência fotovoltaica instalada para o concelho de **Guimarães**, integrado no projeto City4Climate.

## 🚀 Portos de Execução
- **Produção (Local):** Port 8086
- **Ambiente:** Python 3.12 (.venv)

## 📂 Estrutura do Repositório
- `app.py`: Ponto de entrada FastAPI com lógica de IA e integração TimescaleDB.
- `requirements.txt`: Dependências do Python (FastAPI, TensorFlow, SQLAlchemy, etc.).
- `modelo_nn/`: Pasta contendo os artefactos de Inteligência Artificial.
    - `nn_model.h5`: Pesos da Rede Neuronal (Simulador).
    - `previsor_organico.h5`: Modelo de Predição Temporal.
    - `racio_freguesias_guimaraes.csv`: Rácio de potência por instalação específico do concelho.
    - `*_scaler.joblib` & `*_encoder.joblib`: Ficheiros de pré-processamento de dados.

## 🛠️ Instalação e Execução
1. Ativar o ambiente virtual: `source .venv/bin/activate`
2. Instalar dependências: `pip install -r requirements.txt`
3. Correr a API: `python app.py`

## 📡 Endpoints Principais
- `POST /simular`: Calcula potência baseada no número de instalações.
- `POST /simular-meta-kw`: Calcula instalações necessárias para atingir uma meta de kW.
- `GET /historico-db`: Consulta dados históricos no TimescaleDB.
- `GET /prever`: Consulta previsões futuras na base de dados.