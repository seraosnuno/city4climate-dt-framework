--criação da tabela
CREATE TABLE upac_instalacoes (
    id SERIAL PRIMARY KEY,
    trimestre VARCHAR(20),
    distrito VARCHAR(100),
    concelho VARCHAR(100),
    freguesia VARCHAR(150),
    codigo_postal INTEGER,
    tipo_tecnologia VARCHAR(100),
    nivel_tensao VARCHAR(50),
    escalao_potencia_kw VARCHAR(100),
    numero_instalacoes INTEGER,
    potencia_total_instalada_kw NUMERIC,
    codigo_distrito INTEGER,
    codigo_concelho INTEGER,
    codigo_freguesia VARCHAR(50),
    cpes_num NUMERIC,
    relacao_instalacoes_por_cpe NUMERIC,
    relacao_potencia_por_cpe NUMERIC,
    data_insercao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

--Limpeza da tabela
TRUNCATE TABLE upac_instalacoes;

--Criar o trigger para não permitir dados duplicados
CREATE OR REPLACE FUNCTION filtrar_duplicados_upac()
RETURNS TRIGGER AS $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM upac_instalacoes
        WHERE trimestre IS NOT DISTINCT FROM NEW.trimestre
          AND distrito IS NOT DISTINCT FROM NEW.distrito
          AND concelho IS NOT DISTINCT FROM NEW.concelho
          AND freguesia IS NOT DISTINCT FROM NEW.freguesia
          AND codigo_postal IS NOT DISTINCT FROM NEW.codigo_postal
          AND tipo_tecnologia IS NOT DISTINCT FROM NEW.tipo_tecnologia
          AND nivel_tensao IS NOT DISTINCT FROM NEW.nivel_tensao
          AND escalao_potencia_kw IS NOT DISTINCT FROM NEW.escalao_potencia_kw
          AND numero_instalacoes IS NOT DISTINCT FROM NEW.numero_instalacoes
          AND potencia_total_instalada_kw IS NOT DISTINCT FROM NEW.potencia_total_instalada_kw
          AND codigo_distrito IS NOT DISTINCT FROM NEW.codigo_distrito
          AND codigo_concelho IS NOT DISTINCT FROM NEW.codigo_concelho
          AND codigo_freguesia IS NOT DISTINCT FROM NEW.codigo_freguesia
          AND cpes_num IS NOT DISTINCT FROM NEW.cpes_num
          AND relacao_instalacoes_por_cpe IS NOT DISTINCT FROM NEW.relacao_instalacoes_por_cpe
          AND relacao_potencia_por_cpe IS NOT DISTINCT FROM NEW.relacao_potencia_por_cpe
    ) THEN
        RETURN NULL; 
    RETURN NEW; 
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_filtro_upac
BEFORE INSERT ON upac_instalacoes
FOR EACH ROW EXECUTE FUNCTION filtrar_duplicados_upac();

--Consultar a tabela
SELECT * FROM upac_instalacoes;

