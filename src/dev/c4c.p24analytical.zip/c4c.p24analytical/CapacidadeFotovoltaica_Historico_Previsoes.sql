CREATE TABLE upac_previsoes (
    trimestre VARCHAR(10),
    concelho VARCHAR(50),
    freguesia VARCHAR(100),
    numero_instalacoes INT,
    potencia_total_instalada_kw FLOAT,
    tipo VARCHAR(10) DEFAULT 'previsao'
);

SELECT * FROM upac_previsoes;


CREATE OR REPLACE VIEW view_solar_completa AS
-- Dados Reais (Histórico)
SELECT 
    trimestre, 
    concelho,
    freguesia,
    potencia_total_instalada_kw AS potencia,
    numero_instalacoes AS instalacoes, 
    'Historico' AS status
FROM upac_instalacoes

UNION ALL

SELECT 
    trimestre, 
    concelho,
    freguesia,
    potencia_total_instalada_kw AS potencia,
    numero_instalacoes AS instalacoes, 
    'Previsao' AS status
FROM upac_previsoes;

SELECT * FROM view_solar_completa;