import pandas as pd


def process_etl_unico(input_file, output_file):
    print("--- Iniciando ETL Único (Guimarães, Porto, Lisboa) ---")

    # 1. Carregar com sig para limpar o BOM (\ufeff)
    df = pd.read_csv(input_file, sep=None, engine="python", encoding="utf-8-sig")
    df.columns = df.columns.str.strip()

    # Corrigir gralha do original
    if "Número de instalacões" in df.columns:
        df = df.rename(columns={"Número de instalacões": "Número de instalações"})

    # 2. Definir os alvos (Exatos)
    concelhos_alvo = ["Guimarães", "Porto", "Lisboa"]
    df_filtered = df[df["Concelho"].isin(concelhos_alvo)].copy()

    # 3. Remover colunas técnicas (Abstração)
    cols_to_drop = [
        "Código Distrito",
        "Código Concelho",
        "Código Freguesia",
        "CPE's",
        "relacao_instalacoes_por_cpe",
        "relacao_potencia_por_cpe",
        "Código Postal",
        "Distrito",
        "Tipo de Tecnologia",
        "Nível de Tensão",
        "Escalão de potência instalada (kW)",
    ]
    df_filtered = df_filtered.drop(columns=[c for c in cols_to_drop if c in df_filtered.columns])

    # 4. Criar Ano e Trimestre
    df_filtered["Ano"] = df_filtered["Trimestre"].astype(str).str[:4]
    df_filtered["Trimestre_Num"] = df_filtered["Trimestre"].astype(str).str[4:]

    # 5. Agrupar por Concelho e Freguesia
    df_final = (
        df_filtered.groupby(["Concelho", "Freguesia", "Ano", "Trimestre_Num"])
        .agg({"Número de instalações": "sum", "Potência Total Instalada UPAC (kW)": "sum"})
        .reset_index()
    )

    # 6. Ordenar
    df_final = df_final.sort_values(by=["Concelho", "Ano", "Trimestre_Num", "Freguesia"])

    # 7. Guardar ficheiro único
    df_final.to_csv(output_file, index=False, encoding="utf-8")
    print(f"✅ Sucesso! Gerado: {output_file} com os 3 concelhos.")


input_path = "8-unidades-de-producao-para-autoconsumo.csv"
process_etl_unico(input_path, "e8_todos_kw.csv")
