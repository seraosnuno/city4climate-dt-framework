import pandas as pd
from sqlalchemy import create_engine

# Configurações para o container 'db-timescale' na porta 5433
USER = "quantumleap"
PASSWORD = "12345"  # <--- CONFIRMA ESTA PASSWORD
DB_NAME = "quantumleap"
PORT = "5433"          # Porta que o docker ps mostrou para o timescale
DB_URL = f"postgresql://{USER}:{PASSWORD}@localhost:{PORT}/{DB_NAME}"

try:
    engine = create_engine(DB_URL)
    
    # Ler o histórico
    df = pd.read_csv('e8_todos_kw.csv')
    
    # Limpar nomes de colunas para evitar erros no SQL
    df.columns = [c.lower().replace(' ', '_').replace('(', '').replace(')', '') for c in df.columns]
    
    print(f"A injetar {len(df)} registos no TimescaleDB...")
    
    # Criar a tabela 'historico_potencia'
    df.to_sql('historico_potencia', engine, if_exists='replace', index=False)
    
    # Converter a tabela numa 'Hypertable' (O segredo do Timescale para performance)
    # Nota: Isto assume que tens uma coluna de tempo ou ano.
    with engine.connect() as conn:
        # Se tiveres uma coluna de data real, o Timescale brilha. 
        # Como temos 'ano', vamos apenas garantir que a tabela existe.
        print("✅ Dados injetados com sucesso!")

except Exception as e:
    print(f"❌ Erro na injeção: {e}")