import pandas as pd


def process_etl(input_file, output_file, concelho_target):
    print(f"--- Iniciando ETL para: {concelho_target} ---")

    # 1. Carregar com utf-8-sig para limpar o \ufeff (BOM)
    df = pd.read_csv(input_file, sep=None, engine="python", encoding="utf-8-sig")
    df.columns = df.columns.str.strip()

    # Corrigir a gralha do CSV original
    if "Número de instalacões" in df.columns:
        df = df.rename(columns={"Número de instalacões": "Número de instalações"})

    # 2. Filtragem EXATA (para não trazer Porto de Mós quando pedimos Porto)
    df_filtered = df[df["Concelho"] == concelho_target].copy()

    # 3. Colunas a remover (Mantemos a 'Freguesia' agora!)
    cols_to_drop = [
        "Código Distrito",
        "Código Concelho",
        "Código Freguesia",
        "CPE's",
        "relacao_instalacoes_por_cpe",
        "relacao_potencia_por_cpe",
        "Código Postal",
        "Distrito",
        "Tipo de Tecnologia",
        "Nível de Tensão",
        "Escalão de potência instalada (kW)",
    ]
    df_filtered = df_filtered.drop(columns=[c for c in cols_to_drop if c in df_filtered.columns])

    # 4. Criar Ano e Trimestre
    df_filtered["Ano"] = df_filtered["Trimestre"].astype(str).str[:4]
    df_filtered["Trimestre_Num"] = df_filtered["Trimestre"].astype(str).str[4:]

    # 5. Agrupar por Freguesia TAMBÉM
    # Isso vai gerar uma linha para cada freguesia em cada trimestre
    df_final = (
        df_filtered.groupby(["Concelho", "Freguesia", "Ano", "Trimestre_Num"])
        .agg({"Número de instalações": "sum", "Potência Total Instalada UPAC (kW)": "sum"})
        .reset_index()
    )

    # 6. Ordenar para o gráfico fazer sentido (Tempo -> Freguesia)
    df_final = df_final.sort_values(by=["Ano", "Trimestre_Num", "Freguesia"])

    # 7. Guardar
    df_final.to_csv(output_file, index=False, encoding="utf-8")
    print(f"✅ Sucesso! Gerado: {output_file} com freguesias.")


input_path = "8-unidades-de-producao-para-autoconsumo.csv"
process_etl(input_path, "e8_guimaraes_kw.csv", "Guimarães")
process_etl(input_path, "e8_porto_kw.csv", "Porto")
process_etl(input_path, "e8_lisboa_kw.csv", "Lisboa")
