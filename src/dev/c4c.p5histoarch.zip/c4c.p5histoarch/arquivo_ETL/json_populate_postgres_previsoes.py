import requests
import psycopg2

# 1. Configurações de Acesso
API_URL = "http://172.16.131.183:8085/prever"

DB_CONFIG = {
    "dbname": "datawarehouse",
    "user": "admin",
    "password": "password123",
    "host": "localhost",
    "port": "5432"
}

try:
    # 2. Consumo da API corrigida
    print(f"⏳ A ler dados da tua API: {API_URL}...")
    response = requests.get(API_URL)
    response.raise_for_status()
    previsoes = response.json()['data']
    print(f"✅ {len(previsoes)} registos de previsão recebidos.")

    # 3. Ligação ao Postgres (Data Warehouse)
    conn = psycopg2.connect(**DB_CONFIG)
    cur = conn.cursor()

    # Garantir que a tabela existe com a estrutura correta
    cur.execute("""
        CREATE TABLE IF NOT EXISTS upac_previsoes (
            trimestre VARCHAR(20),
            concelho VARCHAR(100),
            freguesia VARCHAR(150),
            numero_instalacoes INTEGER,
            potencia_total_instalada_kw NUMERIC
        );
    """)

    # --- O SEGREDO DA SUBSTITUIÇÃO ---
    print("🧹 A limpar dados antigos (substituição)...")
    cur.execute("TRUNCATE TABLE upac_previsoes;")

    # 4. Injeção dos Novos Dados (Crescimento + Rácio)
    query = """
        INSERT INTO upac_previsoes (trimestre, concelho, freguesia, numero_instalacoes, potencia_total_instalada_kw)
        VALUES (%s, %s, %s, %s, %s)
    """
    
    # Mapeamento exato das chaves que vimos no teu JSON
    data_to_insert = [
        (
            item['trimestre'], 
            item['concelho'], 
            item['freguesia'], 
            item['numero_instalacoes'], 
            item['potencia_total_instalada_kw']
        )
        for item in previsoes
    ]

    cur.executemany(query, data_to_insert)
    
    conn.commit()
    print(f"🚀 SUCESSO! {len(data_to_insert)} registos atualizados no Data Warehouse.")

except Exception as e:
    print(f"❌ Erro na operação: {e}")
    if 'conn' in locals():
        conn.rollback()

finally:
    if 'conn' in locals():
        cur.close()
        conn.close()