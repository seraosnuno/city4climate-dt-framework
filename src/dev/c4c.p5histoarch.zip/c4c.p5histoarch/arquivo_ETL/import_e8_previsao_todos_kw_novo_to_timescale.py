import pandas as pd
from sqlalchemy import create_engine

# Configurações do Timescale (Porta 5433)
DB_URL = "postgresql://quantumleap:12345@localhost:5433/quantumleap"

try:
    engine = create_engine(DB_URL)
    
    # 1. Ler o ficheiro gerado pelo novo modelo (Crescimento + Rácio)
    df = pd.read_csv('e8_previsao_todos_kw_novo.csv')
    
    # 2. Renomear para as colunas que a tua API (app.py) já espera no SQL
    df = df.rename(columns={
        "Concelho": "concelho",
        "Freguesia": "freguesia",
        "Ano": "ano",
        "Trimestre": "trimestre",
        "Num_Instalacoes_Previsto": "num_instalacoes_previstas",
        "Potencia_Total_Prevista_kW": "potencia_total_prevista_kw"
    })
    
    print(f"📥 A injetar {len(df)} novas previsões na tabela 'previsoes_potencia_todos_kw'...")
    
    # 3. Injetar (if_exists='replace' para limpar o lixo antigo)
    df.to_sql('previsoes_potencia_todos_kw', engine, if_exists='replace', index=False)
    
    print("✅ Sucesso! O TimescaleDB agora tem as previsões corrigidas.")

except Exception as e:
    print(f"❌ Erro na injeção de previsões: {e}")