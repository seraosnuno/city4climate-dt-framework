# c4c.p5histoarch
# {P5} DT Historical Data Archival - Guimarães

Este repositório contém a infraestrutura de arquivo de dados históricos para o Digital Twin de Guimarães (City4Climate).

## Componentes Principal (Docker)
O sistema baseia-se em dois serviços principais orquestrados via Docker:
* **TimescaleDB (PostgreSQL 16):** Base de dados otimizada para séries temporais que armazena os dados vindos do QuantumLeap.
* **FIWARE QuantumLeap:** Serviço responsável por persistir o contexto atual do Orion Context Broker no TimescaleDB.

##  Estrutura do Repositório
* **/sql**: Contém os scripts SQL para a criação de tabelas de suporte (`upac_previsoes`) e da View Unificada (`view_solar_completa`).
* **/arquivo_ETL**: Contém os scripts legados em Python utilizados para a limpeza e injeção inicial de dados (CSV -> SQL). 
    * *Nota: Estes scripts servem de referência técnica para a futura implementação de adaptadores Apache NiFi.*

##  Como Levantar a Infraestrutura
Para iniciar os serviços, utilize:
```bash
docker-compose up -d
