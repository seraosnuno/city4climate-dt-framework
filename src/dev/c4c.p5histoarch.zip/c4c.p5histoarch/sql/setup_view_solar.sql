-- Criar tabela de suporte para previsões
CREATE TABLE IF NOT EXISTS upac_previsoes (
    trimestre VARCHAR(10),
    concelho VARCHAR(50),
    freguesia VARCHAR(100),
    numero_instalacoes INT,
    potencia_total_instalada_kw FLOAT,
    tipo VARCHAR(10) DEFAULT 'previsao'
);

-- Criar a View que unifica histórico (do QuantumLeap) e previsões
CREATE OR REPLACE VIEW view_solar_completa AS
SELECT
    trimestre,
    concelho,
    freguesia,
    potencia_total_instalada_kw AS potencia,
    numero_instalacoes AS instalacoes,
    'Historico' AS status
FROM upac_instalacoes
UNION ALL
SELECT
    trimestre,
    concelho,
    freguesia,
    potencia_total_instalada_kw AS potencia,
    numero_instalacoes AS instalacoes,
    'Previsao' AS status
FROM upac_previsoes;
