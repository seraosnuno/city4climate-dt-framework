# c4c.p9eredesadapter

Adaptador da E-redes para injetar os dados provenientes da eredes no orion, no postgres e no neo4j.

## Como Importar
1. No Apache NiFi, crie um novo **Process Group**.
2. Clique com o botão direito e selecione **Upload flow definition**.
3. Selecione o ficheiro `e-redes-adapter-flow.json` presente nesta pasta.